# VIP PRO CASINO

Dự án Android offline gồm 7 trò chơi dùng xu ảo. Giao diện định hướng đen-vàng hoàng gia. Không đăng nhập, không nạp/rút tiền và không giao dịch tiền thật.

## Trò chơi hiện có trong mã nguồn
- Tài Xỉu
- Bầu Cua
- Qiu Qiu
- Pok Deng
- Blackjack
- Chẵn Lẻ
- Bài Cào 3 Lá

## Tài liệu yêu cầu đầy đủ
Mở `PROJECT_SCOPE_1_TO_9.md` để xem toàn bộ 9 nhóm yêu cầu đã thống nhất: giao diện, trò chơi, luật và AI, xu ảo, hiệu ứng/âm thanh, VIP, xoay màn hình, kỹ thuật và sản phẩm bàn giao.

## Tính năng đã có trong mã nguồn hiện tại
- Sảnh chọn 7 trò và màn hình bàn chơi.
- Logic vòng chơi cơ bản cho các trò nêu trên.
- Bài Cào chia 3 lá mỗi bên, lật từng lá và so điểm hàng đơn vị.
- Xu khởi tạo 1.000.000.000 ở lần chạy đầu; lưu số dư và lịch sử bằng local storage.
- Giao diện web chạy offline bên trong Android WebView.
- Workflow GitHub Actions để biên dịch APK debug.

## Các phần vẫn cần hoàn thiện
AI nhiều cấp độ thực sự, VIP Club/nhiệm vụ/vòng quay/quà đăng nhập, nhạc và hiệu ứng âm thanh đầy đủ, biểu tượng cổ vũ thắng/thua, hiệu ứng Jackpot/rung, cũng như kiểm thử xoay màn hình và cân bằng luật/payout. Xem chi tiết trong tài liệu yêu cầu 1–9.

## Build APK qua GitHub
1. Tải và giải nén ZIP.
2. Đưa toàn bộ thư mục `VIP_PRO_CASINO` lên repository GitHub `VIP-PRO-CASINO`.
3. Mở tab **Actions**.
4. Chọn workflow **Build VIP PRO CASINO APK** và chạy workflow.
5. Khi job chạy thành công, tải artifact `VIP-PRO-CASINO-APK`.

ZIP này là mã nguồn dự án, chưa phải APK đã biên dịch. Chỉ coi APK hoàn tất khi GitHub Actions build thành công và tạo ra file APK.
