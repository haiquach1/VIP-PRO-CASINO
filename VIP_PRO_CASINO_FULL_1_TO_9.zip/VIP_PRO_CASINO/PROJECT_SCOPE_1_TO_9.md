# VIP PRO CASINO – BẢN TỔNG HỢP YÊU CẦU 1–9

Tài liệu này gom lại toàn bộ phạm vi đã thống nhất trong cuộc trò chuyện thiết kế game VIP PRO CASINO. Đây là tiêu chuẩn mục tiêu để hoàn thiện sản phẩm; không đồng nghĩa mọi hạng mục đã được lập trình xong trong bản mã nguồn hiện tại.

## 1. Giao diện tổng thể
- Tên game: VIP PRO CASINO.
- Phong cách đen – vàng hoàng gia, cảm giác sảnh casino VIP.
- Có màn hình vào game, sảnh chính riêng và khu vực/bàn chơi riêng cho từng trò.
- Hiển thị số dư xu rõ ràng ở sảnh và trong bàn chơi.
- Nhạc nền vui tươi khi vào game, có nút bật/tắt âm thanh.
- Bố cục ưu tiên điện thoại Android, nút lớn, dễ thao tác.

## 2. Danh sách trò chơi
Tất cả nằm trong cùng một ứng dụng:
1. Tài Xỉu.
2. Bầu Cua.
3. Qiu Qiu.
4. Pok Deng.
5. Blackjack.
6. Chẵn Lẻ.
7. Bài Cào 3 Lá truyền thống.

Mỗi trò cần có bàn chơi, lựa chọn cược, thao tác chơi, hiển thị kết quả và nút chơi ván tiếp theo. Không làm kiểu màn hình chỉ có nút bấm giả lập; mục tiêu là trò chơi có vòng chơi thực tế, chia/lật bài hoặc gieo xúc xắc và xử lý kết quả.

## 3. Cách chơi và đối thủ máy
- Luật tính điểm/kết quả phải được xử lý bằng logic riêng của từng trò.
- Có đối thủ/nhà cái máy ở các trò đối kháng.
- Máy chơi thông minh với nhiều cấp độ, độ khó khác nhau.
- Bài Cào: dùng bộ bài Tây 52 lá; mỗi bên được chia 3 lá; có hiệu ứng chia bài và lật từng lá; A = 1, 2–9 tính theo số, 10/J/Q/K = 0; cộng điểm lấy hàng đơn vị; so điểm người chơi với nhà cái; bằng điểm thì hòa và hoàn cược.
- Qiu Qiu dùng quân domino và cách tính nút theo luật trò chơi.
- Blackjack xử lý giá trị A linh hoạt, hình người 10 điểm và quy tắc nhà cái rút bài.

## 4. Hệ thống xu ảo
- Người chơi mới nhận 1.000.000.000 xu đúng một lần ở lần khởi chạy đầu tiên.
- Không tự đặt lại số dư khi đóng/mở ứng dụng.
- Lưu số dư và lịch sử ván chơi trên điện thoại.
- Thắng thì cộng xu, thua thì trừ xu, hòa thì hoàn cược theo luật trò.
- Xu chỉ là điểm trong game, không có nạp, rút, đổi tiền hoặc giao dịch tiền thật.

## 5. Hiệu ứng, âm thanh và cảm xúc thắng/thua
- Có hiệu ứng chia bài, lật bài, xúc xắc lăn và kết quả.
- Khi thắng hoặc thua đều có biểu tượng/nhân vật cổ vũ phù hợp, không để màn hình khô cứng.
- Có âm thanh thắng, thua và ăn thưởng; có tùy chọn bật/tắt.
- Khi trúng Jackpot: hiệu ứng pháo hoa, xu bay và rung điện thoại (nếu thiết bị hỗ trợ).
- Hiển thị rõ kết quả, số xu thay đổi và trạng thái thắng/thua/hòa.

## 6. Hệ thống VIP
- Có khu VIP Club.
- Có nhiệm vụ để người chơi hoàn thành và nhận phần thưởng xu ảo.
- Có vòng quay may mắn dùng điểm/ lượt miễn phí trong game.
- Có quà đăng nhập hằng ngày.
- Các phần thưởng chỉ là xu/đồ trang trí ảo, không quy đổi thành tiền.

## 7. Tự xoay màn hình
- Tự điều chỉnh hướng màn hình phù hợp với từng trò hoặc bàn chơi.
- Tránh làm mất trạng thái ván chơi khi thiết bị đổi hướng.

## 8. Yêu cầu kỹ thuật và an toàn
- Ứng dụng Android cài trên điện thoại.
- Chơi offline, không yêu cầu đăng nhập và không cần máy chủ để chơi cơ bản.
- Lưu dữ liệu cục bộ trên máy.
- Không nạp tiền thật, không rút tiền, không kết nối giao dịch tiền thật.
- Có tên ứng dụng và biểu tượng VIP PRO CASINO.
- Cần kiểm thử trên điện thoại thật trước khi phát hành APK.

## 9. Sản phẩm bàn giao
- Một dự án Android Studio hoàn chỉnh, gom toàn bộ trò chơi vào một ứng dụng.
- Mã nguồn được sắp xếp rõ ràng, có hướng dẫn sử dụng.
- Có thể đưa lên GitHub repository `VIP-PRO-CASINO`.
- Có GitHub Actions để chạy build APK.
- Sau khi build thành công, tải APK và cài trên điện thoại Android.
- Chỉ xác nhận APK hoàn tất sau khi quy trình build thực tế thành công và file APK đầu ra đã được kiểm tra.

---

## Trạng thái mã nguồn được đóng gói cùng tài liệu này

Bản mã nguồn hiện có gồm project Android WebView, sảnh chọn 7 trò, logic chơi cơ bản cho các trò, lưu xu/lịch sử cục bộ và workflow GitHub Actions để build APK. Các hạng mục như AI nhiều cấp hoàn chỉnh, VIP Club/nhiệm vụ/vòng quay/quà đăng nhập, nhạc/âm thanh hoàn chỉnh, hoạt ảnh Jackpot/rung và tối ưu xoay màn hình vẫn cần tiếp tục triển khai và kiểm thử. Không xem ZIP này là APK đã build.
